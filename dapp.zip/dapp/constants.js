//mainnet
// export const CONTRACT_ADDR = '0xF7143Ba42d40EAeB49b88DaC0067e54Af042E963'
// export const NETWORK_ID = 1
// export const RPC_PROVIDER =
//   'https://eth-mainnet.alchemyapi.io/v2/y5TNPGqpdpZWv-et4ZqfNgxQI3jpVm7P'

//rinkeby
export const CONTRACT_ADDR = '0x709483C1c64345b26ae088Eb4b00531cA2A5192d'
export const NETWORK_ID = 4
export const RPC_PROVIDER =
  'https://eth-rinkeby.alchemyapi.io/v2/AY0xKM-ukEI7SylXUBGWdhrHcyZAyzHr'

//polygon tesetnet
// export const CONTRACT_ADDR = '0xB5Dc9A4478E1AeaF80ac106F19d988f30C9bFD5b'
// export const NETWORK_ID = 80001
// export const RPC_PROVIDER = 'https://matic-mumbai.chainstacklabs.com'
